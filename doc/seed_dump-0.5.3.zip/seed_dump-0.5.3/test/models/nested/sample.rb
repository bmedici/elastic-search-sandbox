class Nested::Sample < ActiveRecord::Base
  attr_accessible :name
end
