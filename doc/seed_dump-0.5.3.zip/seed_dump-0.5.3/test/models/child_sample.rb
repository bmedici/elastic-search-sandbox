class ChildSample < AbstractSample
  attr_accessible :name
end

