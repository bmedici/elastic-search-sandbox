class Sample < ActiveRecord::Base
  attr_accessible :binary, :boolean, :date, :datetime, :decimal, :float, :integer, :string, :text, :time, :timestamp
end
